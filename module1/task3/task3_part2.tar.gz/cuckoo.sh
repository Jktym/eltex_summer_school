#!/bin/bash

FIFO_DIR="/tmp/run"
FIFO="$FIFO_DIR/cuckoo.pid"
LOG_FILE="cuckoo.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

cleanup() {
    log "Shutdown!"
    [ -p "$FIFO" ] && rm -f "$FIFO"
    exit 0
}
trap cleanup SIGTERM SIGINT

mkdir -p "$FIFO_DIR" || exit 1
[ -p "$FIFO" ] && rm -f "$FIFO"
mkfifo "$FIFO" || exit 1

log "Startup!"

while true; do
    # Читаем то, что прислал любой воркер
    if read -r line < "$FIFO"; then
        # Генерируем случайное число от 2 до 10
        N=$(( RANDOM % 9 + 2 ))
        
        # Записываем в лог сервера полученную строку и наш ответ
        log "$line -> $N"
        
        # Сразу отправляем число обратно в канал
        echo "$N" > "$FIFO"
    fi
done

cleanup